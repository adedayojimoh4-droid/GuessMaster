package com.jar.guessmaster

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.View
import android.graphics.Color

class MainActivity : Activity() {
    private lateinit var gameView: WebView

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(11, 18, 38)
        window.navigationBarColor = Color.rgb(11, 18, 38)
        window.decorView.systemUiVisibility = 0

        gameView = WebView(this).apply {
            setBackgroundColor(Color.rgb(11, 18, 38))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = false
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(gameView)
    }

    override fun onBackPressed() {
        if (::gameView.isInitialized && gameView.canGoBack()) {
            gameView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
