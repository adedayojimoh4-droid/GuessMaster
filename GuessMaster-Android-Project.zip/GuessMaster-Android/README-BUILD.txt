GUESS MASTER — ANDROID PROJECT

This is the Android Studio source project for the offline Guess Master game.
It is not yet a compiled APK.

BUILD AN APK:
1. On a computer, install Android Studio from https://developer.android.com/studio
2. Extract this ZIP file.
3. In Android Studio choose File > Open and select the extracted GuessMaster-Android folder
   (the folder containing settings.gradle.kts).
4. Wait for Gradle sync to finish. Allow Android Studio to download the Android SDK / build tools if asked.
   Internet is normally needed for this first setup/build.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Wait for the build to complete, then click the "locate" link in the notification.
   The APK is normally at app/build/outputs/apk/debug/app-debug.apk.
7. Transfer app-debug.apk to your Android phone and tap it to install.
8. If Android asks, allow your file manager/browser to install unknown apps, then retry installation.
   Only install APKs you built or trust.

OFFLINE:
The game page is packaged inside the app. Once installed, the game itself needs no internet.
The first Android Studio build may require internet to download Gradle and SDK components.

PROJECT DETAILS:
App name: Guess Master
Application ID: com.jar.guessmaster
Minimum Android: Android 6.0 (API 23)
No internet permission is requested.
